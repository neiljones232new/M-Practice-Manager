import { Client as ClientNode } from '../interfaces/client.interface';
import { Client as DbClient } from '../../database/interfaces/database.interface';

export interface ClientProfileSubset {
  partnerResponsible?: string;
  clientManager?: string;
  lifecycleStatus?: 'PROSPECT' | 'ONBOARDING' | 'ACTIVE' | 'DORMANT' | 'CEASED';
  statutoryYearEnd?: string;
  vatPeriodStart?: string;
  vatPeriodEnd?: string;
  vatStagger?: 'A' | 'B' | 'C' | 'NONE';
  payrollPayDay?: number;
  payrollPeriodEndDay?: number;
  corporationTaxUtr?: string;
  vatNumber?: string;
  vatScheme?: string;
  vatReturnFrequency?: string;
  vatQuarter?: string;
  payeReference?: string;
  accountsOfficeReference?: string;
  cisRegistered?: boolean;
  cisUtr?: string;
  payrollRtiRequired?: boolean;
  amlCompleted?: boolean;
  clientRiskRating?: string;
}

export interface ClientContext {
  node: ClientNode;
  profile: ClientProfileSubset;
  computed: {
    isVatRegistered: boolean;
    isEmployer: boolean;
    isCompany: boolean;
    isActive: boolean;
    isAmlComplete: boolean;
  };
}

export function buildClientContext(
  node: ClientNode,
  dbClient?: DbClient | null
): ClientContext {
  const profile: ClientProfileSubset = {
    partnerResponsible: dbClient?.partnerResponsible,
    clientManager: dbClient?.clientManager,
    lifecycleStatus: dbClient?.lifecycleStatus,
    statutoryYearEnd: dbClient?.statutoryYearEnd,
    vatPeriodStart: dbClient?.vatPeriodStart,
    vatPeriodEnd: dbClient?.vatPeriodEnd,
    vatStagger: dbClient?.vatStagger,
    payrollPayDay: dbClient?.payrollPayDay,
    payrollPeriodEndDay: dbClient?.payrollPeriodEndDay,
    corporationTaxUtr: dbClient?.corporationTaxUtr,
    vatNumber: dbClient?.vatNumber,
    vatScheme: dbClient?.vatScheme,
    vatReturnFrequency: dbClient?.vatReturnFrequency,
    vatQuarter: dbClient?.vatQuarter,
    payeReference: dbClient?.payeReference,
    accountsOfficeReference: dbClient?.accountsOfficeReference,
    cisRegistered: dbClient?.cisRegistered,
    cisUtr: dbClient?.cisUtr,
    payrollRtiRequired: dbClient?.payrollRtiRequired,
    amlCompleted: dbClient?.amlCompleted,
    clientRiskRating: dbClient?.clientRiskRating,
  };

  return {
    node,
    profile,
    computed: {
      isVatRegistered: Boolean(profile.vatNumber),
      isEmployer: Boolean(profile.payeReference || profile.payrollRtiRequired),
      isCompany: node.type === 'COMPANY',
      isActive: node.status === 'ACTIVE',
      isAmlComplete: Boolean(profile.amlCompleted),
    },
  };
}
