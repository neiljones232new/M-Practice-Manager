import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import * as crypto from 'crypto';

export interface EncryptedData {
  data: string;
  iv: string;
  tag: string;
}

@Injectable()
export class EncryptionService {
  private readonly logger = new Logger(EncryptionService.name);
  private readonly algorithm = 'aes-256-gcm';
  private readonly keyLength = 32; // 256 bits
  private readonly ivLength = 16; // 128 bits
  private readonly tagLength = 16; // 128 bits
  private cachedKey?: Buffer;
  private warnedMissingKey = false;
  private warnedInvalidKey = false;

  constructor(private readonly configService: ConfigService) {}

  /**
   * Get encryption key from environment or generate one
   */
  private getEncryptionKey(): Buffer {
    if (this.cachedKey) {
      return this.cachedKey;
    }

    const keyString = this.configService.get<string>('ENCRYPTION_KEY');
    if (this.isValidKeyString(keyString)) {
      this.cachedKey = Buffer.from(keyString, 'hex');
      return this.cachedKey;
    }
    if (keyString && !this.warnedInvalidKey) {
      this.logger.warn('ENCRYPTION_KEY is present but invalid; expected 64 hex characters (32 bytes).');
      this.warnedInvalidKey = true;
    }

    // Generate a new key if none exists (for development)
    const key = crypto.randomBytes(this.keyLength);
    if (!this.warnedMissingKey) {
      this.logger.warn('No ENCRYPTION_KEY found in environment. Generated temporary key for development.');
      this.logger.warn(`Set ENCRYPTION_KEY=${key.toString('hex')} in your environment for production.`);
      this.warnedMissingKey = true;
    }
    this.cachedKey = key;
    return key;
  }

  hasConfiguredKey(): boolean {
    return this.isValidKeyString(this.configService.get<string>('ENCRYPTION_KEY'));
  }

  private isValidKeyString(keyString?: string): boolean {
    if (!keyString) {
      return false;
    }
    if (keyString.length !== this.keyLength * 2) {
      return false;
    }
    return /^[0-9a-fA-F]+$/.test(keyString);
  }

  /**
   * Encrypt sensitive data
   */
  encrypt(plaintext: string): EncryptedData {
    try {
      const key = this.getEncryptionKey();
      const iv = crypto.randomBytes(this.ivLength);
      
      const cipher = crypto.createCipheriv(this.algorithm, key, iv);
      
      const encrypted = Buffer.concat([
        cipher.update(plaintext, 'utf8'),
        cipher.final()
      ]);
      
      const tag = cipher.getAuthTag();
      
      return {
        data: encrypted.toString('hex'),
        iv: iv.toString('hex'),
        tag: tag.toString('hex'),
      };
    } catch (error) {
      this.logger.error('Encryption failed:', error);
      throw new Error('Failed to encrypt data');
    }
  }

  /**
   * Decrypt sensitive data
   */
  decrypt(encryptedData: EncryptedData): string {
    try {
      const key = this.getEncryptionKey();
      const iv = Buffer.from(encryptedData.iv, 'hex');
      const tag = Buffer.from(encryptedData.tag, 'hex');
      const encrypted = Buffer.from(encryptedData.data, 'hex');
      
      const decipher = crypto.createDecipheriv(this.algorithm, key, iv);
      decipher.setAuthTag(tag);
      
      const decrypted = Buffer.concat([
        decipher.update(encrypted),
        decipher.final()
      ]);
      
      return decrypted.toString('utf8');
    } catch (error) {
      this.logger.error('Decryption failed:', error);
      throw new Error('Failed to decrypt data');
    }
  }

  /**
   * Encrypt an object's sensitive fields
   */
  encryptObject<T extends Record<string, any>>(
    obj: T, 
    sensitiveFields: (keyof T)[]
  ): T {
    const result = { ...obj };
    
    for (const field of sensitiveFields) {
      if (result[field] && typeof result[field] === 'string') {
        result[field] = this.encrypt(result[field] as string) as T[keyof T];
      }
    }
    
    return result;
  }

  /**
   * Decrypt an object's sensitive fields
   */
  decryptObject<T extends Record<string, any>>(
    obj: T, 
    sensitiveFields: (keyof T)[]
  ): T {
    const result = { ...obj };
    
    for (const field of sensitiveFields) {
      if (result[field] && typeof result[field] === 'object') {
        try {
          result[field] = this.decrypt(result[field] as EncryptedData) as T[keyof T];
        } catch (error) {
          this.logger.error(`Failed to decrypt field ${String(field)}:`, error);
          // Keep encrypted data if decryption fails
        }
      }
    }
    
    return result;
  }

  /**
   * Hash sensitive data for comparison (one-way)
   */
  hash(data: string, salt?: string): string {
    const actualSalt = salt || crypto.randomBytes(16).toString('hex');
    const hash = crypto.pbkdf2Sync(data, actualSalt, 10000, 64, 'sha512');
    return `${actualSalt}:${hash.toString('hex')}`;
  }

  /**
   * Verify hashed data
   */
  verifyHash(data: string, hashedData: string): boolean {
    try {
      const [salt, hash] = hashedData.split(':');
      const verifyHash = crypto.pbkdf2Sync(data, salt, 10000, 64, 'sha512');
      return hash === verifyHash.toString('hex');
    } catch (error) {
      this.logger.error('Hash verification failed:', error);
      return false;
    }
  }

  /**
   * Generate secure random token
   */
  generateSecureToken(length: number = 32): string {
    return crypto.randomBytes(length).toString('hex');
  }

  /**
   * Generate secure API key
   */
  generateApiKey(): string {
    const timestamp = Date.now().toString(36);
    const randomPart = crypto.randomBytes(24).toString('base64url');
    return `mdj_${timestamp}_${randomPart}`;
  }
}
